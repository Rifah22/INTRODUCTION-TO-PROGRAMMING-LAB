 #include<iostream>
 using namespace std;
 class Box{
 public:
    float length, width, height;
    Box(){}
    Box(float l,float w, float h)
    {
        length=l;
        width=w;
        height=h;
    }
    Box operator + (Box box2) {
         Box newbox1;
         cout<<"Adding"<<endl;
         newbox1.length=length+box2.length;
         newbox1.width=width+box2.width;
         newbox1.height=height+box2.height;
         return newbox1;
    }
Box operator * (Box obj)
    {
         Box newbox2;
         cout<<"Multiplying"<<endl;
         newbox2.length=(length*obj.length);
         newbox2.width=(width*obj.width);
         newbox2.height=(height*obj.height);
         return newbox2;
    }

    showinfo()
             {
                cout<<"New length is "<<length<<endl;
                cout<<"New width is "<<width<<endl;
                cout<<"New height is "<<height<<endl;
             }

 };

 int main()
 {
     float l1,w1,h1,l2,w2,h2;
     cout<<"Enter the values of Box1 length , width & height:"<<endl;
     cin>>l1;cin>>w1;cin>>h1;
     cout<<"Enter the values of Box2 length , width & height:"<<endl;
     cin>>l2;cin>>w2;cin>>h2;
     Box box1(l1,w1,h1),box2(l2,w2,h2);
     Box Newbox1=box1+box2;
     Box Newbox2=box1*box2;
     Newbox1.showinfo();
     Newbox2.showinfo();
     return 0;
 }

