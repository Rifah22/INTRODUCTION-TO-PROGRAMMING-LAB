#include<iostream>
using namespace std;
class Account{
public:
string aname=" ";
string ano=" ";
float balance;
string atype=" ";
int accountcount;
int getaccountcount(){
return accountcount;
}
Account(){
aname="";
ano="";
balance=0;
atype="";
accountcount ++;
}
Account(string a ,string b ,float c,string t){
aname=a;
ano=b;
balance=c;
atype=t;
accountcount++;
}
Account operator+(int o){
    Account res;
    res.balance=balance+o;
    return res;
}
void showinfo(){
cout<<" Account balance after deposit: "<<balance<<endl;
}
};
int main(){
    Account a2,a4;
Account a1("Simar","SS-6789SIMAR",90000.05,"Agent");
a2=a1+40000;
a2.showinfo();
Account a3("Rima","RR-1234RIMA",50000.0,"Personal");
a4=a3+35000;
a4.showinfo();
return 0;
}

