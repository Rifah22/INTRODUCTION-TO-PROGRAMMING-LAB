#include<iostream>
using namespace std;
class Box{
private:
    int length,breadth,height;
public:
    void returnlbh(int l,int b,int h){
    length=l;
    breadth=b;
    height=h;
    }

    int returnArea(){
    return length*breadth*height;

    }

};
int main(){
Box a;

  a.returnlbh(4,5,6);
  cout<<a.returnArea()<<endl;

  return 0;

}

