#include<iostream>
using namespace std;
class Rectangle{
private:
    int length,breadth,area;
public:
    void returnlb(int l,int b){
    length=l;
    breadth=b;
    }

    int returnArea(){
    return length*breadth;

    }

};
int main(){
Rectangle a;

  a.returnlb(4,5);
  cout<<a.returnArea()<<endl;

  return 0;

}

