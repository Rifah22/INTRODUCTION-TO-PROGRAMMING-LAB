#include<iostream>
using namespace std;
class Employee {
private:
    string Name;
    string Year;
    int Salary;
    string Address;
public:
    void eName(string n){
        Name=n;
    }
    void eYear(string y){
        Year=y;
    }
    void eSalary(int s){
        Salary=s;
    }
    void eAddress(string a){
        Address=a;
    }
    void showEmployeeInfo(){
        cout<<Name<<endl;
        cout<<Year<<endl;
        cout<<Salary<<endl;
        cout<<Address<<endl;
    }
};
int main(){
    Employee e1,e2,e3;
    e1.eName("Robert");
    e1.eYear("1994");
    e1.eSalary(50000);
    e1.eAddress("64C-WallsStreat");
    e1.showEmployeeInfo();

    e2.eName("Sam");
    e2.eYear("2000");
    e2.eSalary(70000);
    e2.eAddress("68D-WallsStreat");
    e2.showEmployeeInfo();

    e3.eName("John");
    e3.eYear("1999");
    e3.eSalary(90000);
    e3.eAddress("26B-WallsStreat");
    e3.showEmployeeInfo();
return 0;
}
