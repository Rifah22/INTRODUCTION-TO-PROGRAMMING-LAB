#include<iostream>
using namespace std;
class Mobile{
private:
    string mownername="";
    string mnumber="";
    float mbalance;
    string mosname;
    bool lockstatus;
public:
    void setmownername(string o){
    mownername=o;
    }
    void setmnumber(string n){
    mnumber=n;
    }
    void setmbalance(float b){
    mbalance=b;
    }
    void setmosname(string s){
    mosname=s;
    }
    void setlockstatus(bool l){
    lockstatus=l;
    }
    string getmownername(){
    return mownername;
    }
    string getmnumber(){
    return mnumber;
    }
    float getmbalance(){
    return mbalance;
    }
    string getmosname(){
    return mosname;
    }
    bool getlockstatus(){
    return lockstatus;
    }
Mobile(){
mownername="";
mnumber="";
mbalance=0;
mosname="";
lockstatus=0;
}
Mobile(string o, string n, float b, string s, bool l){
mownername=o;
mnumber=n;
mbalance=b;
mosname=s;
lockstatus=l;
}
~Mobile(){
}
void showinfo(){
cout<<"Mobile Owner Name:"<<mownername<<endl;
cout<<"Mobile Number:"<<mnumber<<endl;
cout<<"Mobile Balance:"<<mbalance<<endl;
cout<<"Mobile OS Name:"<<mosname<<endl;
}
float recharge(float balance){
mbalance=mbalance+balance;
return mbalance;
}
float CallSomeone(float timeduration){
if(lockstatus==0){
    cout<<"Balance after call";
float cost=timeduration/0.5;
mbalance=mbalance-cost;
}
else {
    cout<<"Phone is locked you can't call"<<endl;
    cout<<"Remaining Balance";
}
return mbalance;
}
};
int main(){
Mobile m1;
 m1.setmownername("Rima");
m1.setmnumber("01234567891");
m1.setmbalance(500.50);
m1.setmosname("Android");
m1.setlockstatus(0);
m1.showinfo();
cout<<"Mobile Balance after recharge"<<m1.recharge(350)<<endl;
cout<<m1.CallSomeone(300)<<endl;

Mobile m2("Simar","01987654321",1000.90,"IOS",1);
m2.showinfo();
cout<<"Mobile Balance after recharge"<<m2.recharge(700)<<endl;
cout<<m2.CallSomeone(750)<<endl;
return 0;
}
