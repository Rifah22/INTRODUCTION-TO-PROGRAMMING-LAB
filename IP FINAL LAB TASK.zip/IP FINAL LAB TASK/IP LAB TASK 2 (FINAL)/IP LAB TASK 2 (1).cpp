#include<iostream>
using namespace std;
class Account{
private:
    string aname;
    string ano;
    float balance;
    string atype;

public:
    void setaname(string o){
    aname=o;
    }
    void setano(string n){
    ano=n;
    }
    void setbalance(float b){
    balance=b;
    }
    void setatype(string t){
    atype=t;
    }
    string getaname(){
    return aname;
    }
    string getano(){
    return ano;
    }
    float getbalance(){
    return balance;
    }
    string getatype(){
    return atype;
    }
Account(){
aname="";
ano="";
balance=0;
atype="";

}
Account(string aname, string ano, float b, string atype){
aname="o";
ano="n";
balance=b;
atype="t";

}
~Account(){
}
void deposit();
void withdraw();
void transfer();
};
void Account::deposit(){
float a;
cout<<"\nEnter Deposit Amount:";
cin>>a;
balance+=a;
void Account::withdraw(){
float a;
cout<<"\n Enter Withdraw Amount:";
cin>>a;
if(a>balance){
    cout<<"\n Cannot Withdraw Amount:";
    balance-=a;
}
}
void Account::transfer(){
float a;
cout<<"Enter A/C of receiver:";
cin>>ano;
cout<<"Enter amount to be transferred:";
cin>>a;
if ((balance-a)>=5000)
{
    for(int i=0;i<5;i++){
        if(ano==i.return a()){
            balace-=a;
            i.balance+=a;
            cout<<"Rs."<<a<<"has been transfered to"<<ano;
            cout<<"\n Your Current Balance:Rs."<<balance;
        }
    }
    if(i==0){
        cout<<"Account not found:";}
        else{
            cout<<"Insufficient Balance:";
        }
}
}
void showAccountDetails(){
 cout<<"\n-------";
 cout<<"\n AName:"<<aname;
 cout<<"\n ANo:"<<ano;
 cout<<"\n Balance:"<<balance;
 cout<<"\n AType:"<<atype;
}
}
int main(){
string aname;
string ano;
float balance;
string atype;
cout<<"\n Enter Details:\n";
cout<<"---------------";
cout<<"\n Account No.";
cin>>ano;
cout<<"\n Name:";
cin>>name;
cout<<"\n Account Type:";
cin>>atype;
cout<<"\n Balance:";
cin>>Balance;
bank b1(aname,ano,balance,atype);
   b1.deposit();
   b1.withdraw();
   b1.transfer();
return 0;
}
