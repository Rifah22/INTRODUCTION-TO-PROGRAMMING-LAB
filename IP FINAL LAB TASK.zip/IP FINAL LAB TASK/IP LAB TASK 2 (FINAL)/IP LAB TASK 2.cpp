#include<iostream>
using namespace std;
class Account{
private:
string aname="";
string ano="";
float balance;
string atype="";
public:
int accountcount;
int getaccountcount(){
return accountcount;
}
void setaname(string a){
aname=a;
}
void setano(string b){
ano=b;
}
void setbalance(float c){
balance=c;
}
void setatype(string t){
atype=t;
}
string getaname(){
return aname;
}
string getano(){
return ano;
}
float getbalance(){
return balance;}
string getatype(){
return atype;}
Account(){
aname="";
ano="";
balance=0;
atype="";
accountcount ++;
}
Account(string a ,string b ,float c,string t){
aname=a;
ano=b;
balance=c;
atype=t;
accountcount++;
}
~Account(){
}
void showinfo(){
cout<<"Account Name: "<<aname<<endl;
cout<<"Account No: "<<ano<<endl;
cout<<"Balance: "<<balance<<endl;
cout<<"Account type: "<<atype<<endl;
}
float deposit(int amount){
balance=balance+amount;
return balance;
}
float withdraw(int amount){
balance=balance-amount;
return balance;
}
void transfer(int amount,Account &receiver){
balance=balance-amount;
receiver.balance=receiver.balance+amount;
cout<<"  money transfered "<<aname<<"  account balance: "<< balance<<endl;
cout<<"  money received "<<receiver.aname<<"  account balance: "<<receiver.balance<<endl;
}
};
int main(){
Account a1("Simar","SS-6789SIMAR",90000.05,"Agent"),a2("Rima","RR-1234RIMA",50000.0,"Personal");
a1.showinfo();
cout<<"New balance after deposit: "<<a1.deposit(5000.65)<<endl;
cout<<"New balance after withdraw: "<<a1.withdraw(3500.95)<<endl;
a2.showinfo();
cout<<"New balance after deposit: "<<a2.deposit(4680)<<endl;
cout<<"New balance after withdraw: "<<a2.withdraw(3905)<<endl;
a1.transfer(2500,a2);



return 0;
}

