#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int n1,n2,reminder;
    cout<<"ener your a value of n1 and n2 ";
    cin>>n1>>n2;
    if(n1%2==0)
    {
        cout<<" n1 is an Even Number "<<endl;

    }
    else{
        cout<<" n1 is a Odd number ";
    }

    if(n2%2==0)
    {
        cout<<" n2 is an Even Number "<<endl;

    }
    else{
        cout<<" n2 is a Odd number "<<endl;
    }
    if(n1>n2){cout<<"n1 is maximum of two numbers"<<n1;}
    else{cout<<"n2 is maximum of two numvers"<<n2;}
    return 0;
}

