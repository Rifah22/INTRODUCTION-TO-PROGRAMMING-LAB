#include<iostream>
#include<string.h>
using namespace std;
int main()
{
     int n;
     cout<<" How many characters ?"<<endl;
     cin>>n;
     cout<<" Weite a word which must have the latter 'C' "<<endl;
     char word[n];
     cin>>word[n];
     if(word[0]=='c'||word[0]=='C')
     {
        cout<<" Your given word "<<word[n]<<" has "<<n<<" character and character "<<word[0];

     }
     else
     {
         cout<<" your word dosn't starts with c";
     }
     return 0;
}
