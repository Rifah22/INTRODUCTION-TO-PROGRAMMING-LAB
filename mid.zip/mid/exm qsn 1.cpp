#include<iostream>
using namespace std;
int main()
{
  float g,n,n1;
  cout<<" Enter your cgpa ";
  cin>>g;
  cout<<endl;

  cout<<" Enret your number of greade lower than B+ ";
  cin>>n;
  cout<<endl;

  cout<<" Enter number of course drop ";
  cin>>n1;
  cout<<endl;

  cout<<" CGPA: "<<g<<endl;
  cout<<" number of grade lower than B+"<<n<<endl;
  cout<<" number of course drop: "<<n1<<endl;

  if(g>=3.75&&n==0&&n1==0)
  {
      cout<<" You are applicable for 45% financial AID";
  }
  else if(g<3.75&&g>=3.65&&n==0&&n1<=1)
  {
      cout<<" you are applicable for 20% financial AID";
  }
  else if(g<3.65&&g>=3.50&&n<=1&&n1<=3)
  {
      cout<<" you are applicable for 10% financial AID";
  }
  else
  {
      cout<<" you are not applicable for finencial AID";
  }
  return 0;
}
