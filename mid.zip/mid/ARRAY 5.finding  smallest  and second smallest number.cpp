
#include<iostream>
using namespace std;
int main()
{
    int N,smallest=0,second_smallest=0,i;
    cout<<"Enter the size of array ";
    cin>>N;
    int ary[N];
    cout<<"Enter some values of the array"<<endl;
    for(i=0;i<N;i++)
    {
        cin>>ary[i];
    }
    smallest=INT_MAX;
    for(i=0;i<N;i++)
    {
        if(ary[i]<smallest)
        {
            smallest=ary[i];
        }
    }
    cout<<" The smallest number is "<<smallest<<endl;
    second_smallest=INT_MAX;
    for(i=0;i<N;i++)
    {
        if(ary[i]>smallest && second_smallest>ary[i])
        {
            second_smallest=ary[i];
        }
    }
    cout<<" The second smallest number is "<<second_smallest<<endl;
    return 0;
}

