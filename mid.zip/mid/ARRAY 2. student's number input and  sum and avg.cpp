#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int N,sum=0,avg,i,M,s;
    cout<<"Enter how much students are? ";
    cin>>N;
    int student[N];
    cout<<"Enter the students marks one by one"<<endl;
    for(i=0;i<N;i++)
    {
        cout<<"Marks of student "<<i+1<<"= ";
        cin>>student[i];
    }
    for(i=0;i<N;i++)
    {
        s=student[i];
        sum=sum+s;
    }
    cout<<"Total mark of the students = "<<sum<<endl;
    avg=sum/N;
    cout<<"The average marks is = "<<avg;
}
