#include<iostream>
using namespace std;
int main()
{
    float l=INT_MAX,sl=INT_MAX;
    int n,i;
    cout<<"how many students?"<<endl;
    cin>>n;
    float mrk[n];
    cout<<" enter  midterm marks one by one "<<endl;
    for(i=0;i<n;i++)
    {
        cin>>mrk[i];
    }
    for(i=0;i<n;i++)
    {
        if(mrk[i]<l)
        {
            l=mrk[i];
        }
    }
    cout<<" Lowest markis "<<l<<endl;
    for(i=0;i<n;i++)
    {
        if(mrk[i]<sl&&mrk[i]!=l)
        {
          sl=mrk[i];
        }
    }
    cout<<"second lowest mark is :"<<sl<<endl;
return 0;
}
