#include<iostream>
using namespace std;
int main()
{
    int i,N;
    cout<<"Enter word size "; cin>>N;
    cout<<endl;
    char word[N];
    cout<<"Enter a word "<<endl;
    for(i=0;i<N;i++)
    {
        cin>>word[i];
    }
    for(i=0;word[i]!='\0';i++)
    {
        if(word[i]=='a'|| word[i]=='A'|| word[i]=='e'|| word[i]=='E'|| word[i]=='I'|| word[i]=='i'||word[i]=='o'|| word[i]=='O'|| word[i]=='u'|| word[i]=='U')
        {
            cout<<word[i]<<" is vowel "<<endl;
        }
        else
        {
            cout<<word[i]<<" is consonant "<<endl;
        }
    }
    return 0;
}
