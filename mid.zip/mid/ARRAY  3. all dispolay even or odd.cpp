#include<iostream>
using namespace std;
main()
{
    int N,i,s;
    cout<<"Enter a value of N"<<endl;
    cin>>N;
    int number[N];
    for(i=0;i<N;i++)
    {
        cout<<i+1<<" no value is ";
        cin>>number[i];
    }
    for(i=0;i<N;i++)
    {
        s=number[i];
        if(s%2==0)
        {
            cout<<s<<" is an even number. "<<endl;
        }
        else
        {
            cout<<s<<" is an odd number. "<<endl;
        }
    }
    return 0;
}
