#include<iostream>
using namespace std;
int main()
{
    float l=INT_MAX,sl=INT_MAX,l1=INT_MAX,sl1=INT_MAX;
    int n,i;
    cout<<"Number of students: ";
    cin>>n;
    cout<<endl;
    float qz[n],qz1[n];
    cout<<"QUIZ-1 Maeks: "<<endl;
    for(i=0;i<n;i++)
    {
        cin>>qz[i];
    }

    cout<<"QUIZ-2 Maeks: "<<endl;
    for(i=0;i<n;i++)
    {
        cin>>qz1[i];
    }

    for(i=0;i<n;i++)
    {
        if(qz[i]<l)
        {
            l=qz[i];
        }
    }

    for(i=0;i<n;i++)
    {
        if(qz[i]<sl&&qz[i]!=l)
        {
          sl=qz[i];
        }
    }
    for(i=0;i<n;i++)
    {
        if(qz1[i]<l1)
        {
            l1=qz1[i];
        }
    }

    for(i=0;i<n;i++)
    {
        if(qz1[i]<sl1&&qz1[i]!=l1)
        {
          sl1=qz1[i];
        }
    }
    cout<<" worst quizws  "<<endl<<l<<endl<<l1<<endl<<sl<<endl<<sl1;
return 0;
}

