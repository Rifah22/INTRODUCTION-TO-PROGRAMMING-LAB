#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int no1, no2,multiple;
    cout<<"Enter two value of no1 and no2"<<endl;
    cin>>no1>>no2;
    multiple=no1%no2;
    if(multiple==0){cout<<no1<<" is a multiple of "<<no2<<endl; }
    else{cout<<no1<<" is not a multiple of "<<no2<<endl;}
    return 0;
}
