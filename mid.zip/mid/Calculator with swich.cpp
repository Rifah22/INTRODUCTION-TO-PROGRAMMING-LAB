#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float value1, value2;
    char op;
    cout<<"Type in your expration"<<endl;
    cin>>value1>>op>>value2;
    switch(op){
    case '+':
            cout<<"Adition "<<value1+value2<<endl;
    break;
    case '-':
           cout<<"subtraction "<<value1-value2<<endl;
           break;
    case '*':
          cout<<"multiplocayion "<<value1*value2<<endl;
          break;
    case '/':
          cout<<"division "<<value1/value2<<endl;
          break;
    case '%':
          cout<<"mod"<<(int)value1%(int)value2<<endl;
          break ;
    case '^':
        cout<<"POWER CALCULTION  " <<pow(value1,value2)<<endl;
        break;
    default:
        cout<<"Invalide oparetor"<<endl;

    }
    return 0;

}
