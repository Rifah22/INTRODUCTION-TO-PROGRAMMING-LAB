#include<iostream>
using namespace std;
int main()
{
    int year,rem_4,rem_100,rem_400;
    cout<<"Enter the year to be tested ";
    cin>>year;
    rem_4=year%4;
    rem_100=year%100;
    rem_400=year%400;

}
