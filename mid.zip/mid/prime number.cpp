#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int i,n,count=0,p;
    cout<<" enter a number "<<endl;
    cin>>n;cout<<endl;
    for(i=1;i<=n;i++)
    {
        p=n%i;
        if(p==0)
        {
            count+=1;
        }
    }
    if(count==2)
    {
        cout<<n<<" is a prime number. "<<endl;
    }
    else
    {
        cout<<n<<" is not a prime number.";
    }
    return 0;
}
