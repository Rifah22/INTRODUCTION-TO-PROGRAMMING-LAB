#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float m,h,bmi;
    cout<<"Enter your mass in kilogram and high in meters " ;
    cin>>m>>h;
    bmi=m/(h*h);
    cout<<"Your BMI is "<<bmi;
    return 0;

}

