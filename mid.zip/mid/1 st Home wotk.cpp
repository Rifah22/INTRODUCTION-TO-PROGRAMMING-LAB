#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float a,b,c,x,x1,x2;
    cout<<"Enter a value of a  ";
    cin>>a;
    cout<<"Enter a value of b  ";
    cin>>b;
    cout<<"Fnter a value of c  ";
    cin>>c;
    x=(b*b)-4*a*c;
    x1=(-b+sqrt(x))/2*a;
    x2=(-b-sqrt(x)/2*a);
    cout<<"Value of x1 is  "<<x1;
    cout<<"Value of x2 is  "<<x2;
    return 0;
}
