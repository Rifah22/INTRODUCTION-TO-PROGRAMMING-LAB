include<iostream>
using namespace std;
int main()
{
    int N,largest=0,second_largest=0,i;
    cout<<"Enter the size of array ";
    cin>>N;
    int ary[N];
    cout<<"Enter some values of the array"<<endl;
    for(i=0;i<N;i++)
    {
        cin>>ary[i];
    }
    largest=INT_MIN;
    for(i=0;i<N;i++)
    {
        if(ary[i]>largest)
        {
            largest=ary[i];
        }
    }
    cout<<" The largest number is "<<largest<<endl;
    second_largest=INT_MIN;
    for(i=0;i<N;i++)
    {
        if(ary[i]>second_largest && ary[i]!=largest)
        {
            second_largest=ary[i];
        }
    }
    cout<<" The second largest number is "<<second_largest<<endl;
    return 0;

}
