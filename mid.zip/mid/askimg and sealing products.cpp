#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float product1=200.75, product2=345.50, product3=775.75, product4=400.35, product5=1200.75,total_amount,pnumber,amount,p;
    cout<<"Enter the product number (1 or 2 or 3 or 4 or 5) "<<endl;
    cin>>pnumber;

    if(pnumber==1){p=product1;}
    else if(pnumber==2){p=product2;}
    else if(pnumber==3){p=product3;}
    else if(pnumber==4){p=product4;}
    else if(pnumber==5){p=product5;}
    cout<<"Product amount "<<endl;
    cin>>amount;
    total_amount=amount*p;
    cout<<"The total amount is "<<total_amount;
    return 0;

}
