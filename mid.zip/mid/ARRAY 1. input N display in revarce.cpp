#include<iostream>
using namespace std;
int main()
{
    int index, N;
    cout<<"Enter a value of N "<<endl;
    cin>>N;
    int input[N];
    for(index=0;index<N;index++)
    {
        cout<<"Enter a value of ["<<index<<"]= ";
        cin>>input[index];
    }
    cout<<"We are printing the values in a reverse order "<<endl;
    for(index=index-1;index>=0;--index)
    {
        cout<<input[index]<<endl;
    }
    return 0;
}
