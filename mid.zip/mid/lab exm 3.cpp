#include<iostream>
using namespace std;
int min()
{
cout<<"hellow word";

return 0;
}
