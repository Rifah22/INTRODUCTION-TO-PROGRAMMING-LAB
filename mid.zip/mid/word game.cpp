#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    int N;
    string ch,ans;
    cout<<" How many characters? "<<endl;
    cin>>N;
    cout<<" Mustn have the character : "<<endl;
    cin>>ch;
    cout<<" Write your answer : ";
    cin>>ans;
    if(N==ans.length()&&ans[0]==ch[0])
    {
        cout<<" Your given word "<<ans<<" has "<<N<<" characters and character "<<ch<<endl;
    }
    else
    {
        cout<<" Your answer is worong";
    }
    return 0;
}
