#include<iosream>
using namespace std;
int min()
{
float gpa,n,nn;
cout<<" Enter your cgpa ";
cin>>gpa;
cout<<endl;

cout<<" enter number of grade lower than B+";
cin>>n;
cout<<endl;

cout<<"Enter the number of course drop";
cin>>nn;
cout<<endl;

//if(gpa>=3.75&&n==0&&n1==0)
//{
//    cout<<" You are Applicable for 45% Scolarship"<<endl;
//}



return 0;
}
