#include<iostream>
#include<math.h>
using namespace std;
int main()
{
     float r,b,h,a,area,n;
     cout<<" which area do you want to calcilate? "<<endl;
     cout<<" if it is circle press 1 "<<endl;
     cout<<" if it is rectangle press 2 "<<endl;
     cout<<" if it is triangle press 3 "<<endl;
     cout<<" if it is square press 4 "<<endl;
     cin>>n;
     if(n==1)
     {
         cout<<" input the redious of the circle "<<endl;
         cin>>r;
         area=3.1416*r*r;
         cout<<" the area of the circle is "<<area;
     }
     if(n==2)
     {
         cout<<" input the base of the rectangle ";
         cin>>b;
         cout<<endl;
         cout<<" input the hight of the rectangle ";
         cin>>h;
         cout<<endl;
         area=h*b;
         cout<<" the area of the triangle is "<<area;
     }
     if(n==3)
     {
         cout<<" input the base of the triangle ";
         cin>>b;
         cout<<endl;
         cout<<" input the hight of the triangle ";
         cin>>h;
         cout<<endl;
         area=0.5*h*b;
         cout<<" the area of the triangle is "<<area;
     }
     if(n==4)
     {
         cout<<" enter the arm size of the square ";
         cin>>a;cout<<endl;
         area=a*a;
         cout<<"the area of the square is "<<area;
     }
     return 0;
}
