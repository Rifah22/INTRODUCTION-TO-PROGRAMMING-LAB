#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int first,last,sum=0,i;
    cout<<"Enter a value of first number"<<endl;
    cin>>first;
    cout<<"Enter a value of last numver"<<endl;
    cin>>last;

    for(int i=first;i<last;i++)
        if(i%2==0){
        sum=sum+i;}
    cout<<sum<<endl;
    return 0;
}
