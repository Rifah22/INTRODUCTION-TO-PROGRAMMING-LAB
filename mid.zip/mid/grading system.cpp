#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<" Enter your marks";
    cin>>n;
    if(n<=INT_MAX&&n>=101)
    {
        cout<<" You entered a wrong mark ";
    }
    if(n<=100&&n>=80)
    {
        cout<<" Your grade is A+ "<<endl;
        cout<<" Your grade point is 4 ";
    }
    if(n<=89&&n>=75)
    {
        cout<<" Your grade is A "<<endl;
        cout<<" Your grade point is 3.75 ";
    }
    if(n<=74&&n>=70)
    {
        cout<<" Your grade is A- "<<endl;
        cout<<" Your grade point is 3.50 ";
    }
    if(n<=69&&n>=65)
    {
        cout<<" Your grade is B+ "<<endl;
        cout<<" Your grade point is 3.25 ";
    }
    if(n<=64&&n>=60)
    {
        cout<<" Your grade is B "<<endl;
        cout<<" Your grade point is 3.00 ";
    }
    if(n<=59&&n>=55)
    {
        cout<<" Your grade is B- "<<endl;
        cout<<" Your grade point is 2.75 ";
    }
    if(n<=54&&n>=50)
    {
        cout<<" Your grade is C+ "<<endl;
        cout<<" Your grade point is 2.50 ";
    }
    if(n<=49&&n>=45)
    {
        cout<<" Your grade is C "<<endl;
        cout<<" Your grade point is 2.25 ";
    }
    if(n<=44&&n>=40)
    {
        cout<<" Your grade is D "<<endl;
        cout<<" Your grade point is 2.00 ";
    }
    if(n<=39&&n>=0)
    {
        cout<<" Your grade is F "<<endl;
        cout<<" Your grade point is 0.00 ";
    }
    return 0;
}
