#include<iostream>
using namespace std;
int min()
{




return 0;
}
