#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    float value1, value2;
    char op;
    cout<<"Type in your expration"<<endl;
    cin>>value1>>op>>value2;
    if(op =='+'){cout<<"Adition; "<<value1+value2<<endl;}
    else if(op=='-'){cout<<"subtraction"<<value1-value2<<endl;}
    else if(op=='*'){cout<<"multiplocayion"<<value1*value2<<endl;}
    else if(op=='/'){cout<<"division"<<value1/value2<<endl;}
    else if(op=='%'){cout<<"mod"<<(int)value1%(int)value2<<endl;}
     else if(op == '^'){cout<<"POWER CALCULTION : " <<pow(value1,value2)<<endl;}
    else{ cout<<"Invalide oparetor"<<endl;}
        return 0;
}
