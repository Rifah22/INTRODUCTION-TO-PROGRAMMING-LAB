#include <iostream>​
using namespace std;
int main()
{
  int fibonacci [15],i;
  fibonacci[0]=0;//for fibonacci we need to print the 0 and 1 at the very first of the cerise.
  fibonacci[1]=1;
  for(i=2;i<15;i++)
  {
      fibonacci[i]=fibonacci[i-2]+fibonacci[i-1];
  }
  for(i=0;i<15;++i)
    cout<<"Fibonacci ["<<i<<"]="<<fibonacci[i]<<endl;
  return 0;
}
