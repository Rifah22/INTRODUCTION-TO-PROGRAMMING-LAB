#include <iostream>
using namespace std;
class Adder{
     public:
 // interface to outside world
      void addNum(int number) {
               total += number;
                }
 // interface to outside world
      int getTotal() {
                   return total;
                    };
    private:
// hidden data from outside world
int total = 2;
};
int main( ){
    Adder a;
      a.addNum(10);
      a.addNum(20);
      a.addNum(30);
   cout << "Total "
        << a.getTotal();
   return 0;
}
