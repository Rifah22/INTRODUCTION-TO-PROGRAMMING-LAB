#include <iostream>
using namespace std;

void printMessage (void)
{
	cout<<"Programming is fun"<<endl;
}


int main (void)
{
	printMessage ();

	printMessage ();
	return 0;
}
