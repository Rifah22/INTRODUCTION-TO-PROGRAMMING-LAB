#include<iostream>
using namespace std;
int main(){
float mark,grade,gradepoint;
cout<<"Enter mark :";
cin>>mark;

cout<<"\n grade";
cout<< "\n grade point";
if(mark>=90 && mark<=100){
    cout<<"\n A+";
    cout<<"\n 4.00";}
else if (mark>=85 && mark<=89){
    cout<<"\n A";
    cout<<" \n3.75";}
else if (mark>=80 && mark<=84){
    cout<<"\n B+";
    cout<<"\n 3.50";}
else if (mark>=75 && mark<=79){
    cout<<"\n B";
    cout<<"\n 3.25";}
else if (mark>=70 && mark<=74){
    cout<<"\n C+";
    cout<<"\n 3.00";}
else if (mark>=65 && mark<=69){
    cout<<"\n C";
    cout<<"\n 2.75";}
else if (mark>=60 && mark<=64){
    cout<<"\n D+";
    cout<<"\n 2.50";}
else if (mark>=50 && mark<=59){
    cout<<"\n D";
    cout<<"\n 2.25";}
else {
    cout<<"\n F";
    cout<<"\n 0.00";
}

    cout<<endl;
    return 0;

}
