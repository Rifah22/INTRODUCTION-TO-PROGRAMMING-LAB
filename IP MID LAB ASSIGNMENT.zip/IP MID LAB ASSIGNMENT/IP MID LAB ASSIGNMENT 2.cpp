#include<iostream>
using namespace std;
int main (){
    int i,n;
    char letter;
    cout<<"How many alphabet :";
    cin>>n;
    cout<<"Must have the letter:";
    cin>>letter;
    char ans[n];
    cout<<"Write your  answer:";
    for(i=0;i<n+1;i++){
    cin>>ans[i];
    }
        cout<<"Your Given Word"<<ans[i]<<"has"<<" "<<n<<"letter and letter"<<" "<<letter;

        return 0;


}

