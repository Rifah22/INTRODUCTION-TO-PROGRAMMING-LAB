#include <iostream>
#include<math.h>
using namespace std;
int main  (){
int ch;
float a,w,c,s,r,area;
cout<<"1.Area of circle\n2.Area of rectangle\n3.Area of triangle\n4.Area of square";

cout<<"\nEnter your choice:";
cin>>ch;
switch(ch)
{
    case 1:{
    cout<<"Enter radius of the circle:";
    cin>>r;
    area=3.1416*r*r;
    cout<<"Area="<<area;
    break;
    }
    case 2:{
    cout<<"Enter length and width:";
    cin>>a>>w;
    area=a*w;
    cout<<"Area="<<area;
    break;
    }
    case 3: {
    cout<<"Enter three sides of the triangle:";
    cin>>a>>w>>c;
    s=(a+w+c)/2;
    area=sqrt(s*(s-a)*(s-w)*(s-c));
    cout<<"Area="<<area;
    break;
    }
    case 4: {
    cout<<"Enter the side:";
    cin>>s;
    area=(s*s);
    cout<<"Area="<<area;
    break;
    }
    default:
    cout<<" wrong";
    break;


    return 0;
    }
}
