#include<iostream>
using namespace std;
int main (){
int subjects,i;
float marks,total=0.0f,averageMarks;
cout<<"enter number of subjects"<<endl;
cin>>subjects;
cout<<"Enter marks of subjects"<<endl;
for(i=0;i<subjects;i++){
    cin>>marks;
    total+=marks;
}
averageMarks=total/subjects;
cout<<"Total Marks"<<total;
cout<<"Average Marks"<<averageMarks;
return 0;


}
