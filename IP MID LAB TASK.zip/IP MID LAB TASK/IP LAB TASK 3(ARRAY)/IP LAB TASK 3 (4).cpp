#include<iostream>
using namespace std;
int main(){
int i,n,arr[n];
int max1,max2;
cout<<"Enter Size of the Array:";
cin>>n;
cout<<"Enter Elements in the Array:";
for(i=0;i<n;i++){
    cin>>arr[i];
}
max1=max2=INT_MIN;
for(i=0;i<n;i++){
        if(arr[i]>max1){
            max2=max1;
            max1=arr[i];
        }
        else if (arr[i]>max2){
            max2=arr[i];
        }

}
cout<<"First Largest Element="<<max1;
cout<<"\n Second Largest Element="<<max2;
return 0;
}
