#include<iostream>
using namespace std ;
int main (){
int  n,i;
char arr[10];

cout<<"Enter number of character : ";
cin>>n;
cout<<"Enter an alphabet : ";


for(i=0;i<n;i++){
    cin>>arr[i];
}
for(i=0;i<n;i++){
    if(arr[i]=='a'||arr[i]=='e'||arr[i]=='i'||arr[i]=='o'||arr[i]=='u'||arr[i]=='A'||arr[i]=='E'||arr[i]=='I'||arr[i]=='O'||arr[i]=='U'){
        cout<<"vowels"<<" ";
    }
    else{
        cout<<"consonant"<<" ";
    }
}
return 0;
}
