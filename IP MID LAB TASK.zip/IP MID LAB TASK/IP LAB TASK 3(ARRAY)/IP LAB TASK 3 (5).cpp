#include<iostream>
using namespace std;
int main (){
int i,n,arr[n];
int min1,min2;
cout<<"Enter the Size of Array:";
cin>>n;
cout<<" Enter Elements in the Array: ";
for(i=0;i<n;i++){
    cin>>arr[i];
}
    if(arr[0]<arr[1]){
        min1=arr[0];
        min2=arr[1];
    }
    else{
        min1=arr[1];
        min2=arr[0];
    }
for (i=2;i<n;i++){
    if(arr[i]<min1){
        min2=min1;
        min1=arr[i];
}
   else if(arr[i]<min2){
            min2=arr[i];
    }
}
cout<<"\n Smallest Element is: "<<min1;
cout<<"\n Second Smallest Element is: "<<min2;
return 0;
}
