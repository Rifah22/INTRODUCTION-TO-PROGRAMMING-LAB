#include<iostream>
using namespace std;
int main (){
int i,N,arr[N],even=0,odd=0;
cout<<"Enter The Size Of Array : ";
    cin>>N;
cout<<"Enter The Elements Of Array :";
for(i=0;i<N;i++)
    cin>>arr[i];
for(i=0;i<N;i++){
    if(arr[i]%2==0){
        even++;}
    else{
        odd++;}
}
cout<<"\n  Even Numbers of the array are \n " <<even ;
cout<<"\n  Odd Numbers of the array are \n " <<odd ;

return 0;
}
