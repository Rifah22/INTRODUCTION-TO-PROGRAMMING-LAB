#include<iostream>
using namespace std;
int main (){
int N,reverseN=0,digit;
cout<<"Enter your number"<<endl;
cin>>N;
while(N!=0){
    digit=N%10;
    reverseN=reverseN*10+digit;
    N=N/10;
}
cout<<"Reversed Number"<<reverseN<<endl;

return 0;



}
