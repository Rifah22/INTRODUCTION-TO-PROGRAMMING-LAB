#include<iostream>
using namespace std;
int main(){
float BMI,mass,height;
cout<<"Enter mass in kilograms:"<<endl;
cout<<"Enter height in meters :"<<endl;
cin>>mass;
cin>>height;
BMI=(mass)/(height*height);
if(BMI<18.5){
    cout<<"user's BMI under mass"<<endl;

}
else if (BMI>18.5 && BMI<25){
    cout<<"user's BMI normal"<<endl;
}
else if (BMI>25 && BMI<30){
    cout<<"user's BMI over mass"<<endl;
}
else if (BMI>30){
    cout<<"user's BMI obes"<<endl;
}
return 0;




}
