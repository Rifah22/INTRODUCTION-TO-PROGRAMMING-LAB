#include<iostream>
using namespace std;
int main(){

int a,b,reminder;
cout<<"Enter value a,b"<<endl;
cin>>a>>b;
if(a%2==0){
cout<<"a is Even number"<<endl;

}
else{
cout<<"a is a odd number";

}
if(b%2==0){
 cout<<"b is an Even number"<<endl;


}
else{
cout<<"b is a Odd number"<<endl;

}

if (a>b){
    cout<<"a is maximum of two numbers"<<endl;
}
else{
    cout<<"b is maximum of two numbers"<<endl;
}
return 0;
}


