#include<iostream>
using namespace std;
int main (){
int x1,x2;
cout<<"Enter the two int numbers :"<<endl;
cin>>x1>>x2;
if(x1%x2==0){

 cout<<"first number is multiple of second number"<<endl;

}

else {

    cout<<"first number is not multiple of second number"<<endl;

}

return 0;}
