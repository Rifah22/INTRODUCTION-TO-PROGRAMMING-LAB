#include<iostream>
#include<math.h>
using namespace std;
int main(){
float pnumber,p1,p2,p3,p4,p5,q,pprice,amount ;
cout<<"Enter product number:"<<endl;
cin>>pnumber;
cout<<"Enter quantity :"<<endl;
cin>>q;
if(p1==200.75){amount=q*200.75;}
else if(p2==345.50){amount=q*345.50;}
else if (p3==775.75){amount=q*775.75;}
else if (p4==400.35){amount=q*400.35;}
else if (p5==1200.75){amount=q*1200.75;}

cout<<"sold product number:"<<q<<endl;
cout<<"sold product amount:"<<amount<<endl;

return 0;

}
