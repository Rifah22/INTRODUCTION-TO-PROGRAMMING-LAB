#include<iostream>
using namespace std;
int main(){
int i,sum_even=0 ;

for(int i=3;i<=10;i++){
    if(i%2==0){
    cout<<i<<endl;}
            {
       sum_even= sum_even+3;
    }
}

return 0;

}
