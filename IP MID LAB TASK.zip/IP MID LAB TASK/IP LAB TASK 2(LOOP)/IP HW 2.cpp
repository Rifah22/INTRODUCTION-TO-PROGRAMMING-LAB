#include<iostream>
using namespace std;
int main(){
int i,N;
long double fact=1.0;
cout<<"Enter a positive integer:";
cin>>N;
if(N<0)
    cout<<"Error!Factorial of a negative number doesn't exist";
else{
for ( i=1;i<=N;++i){
    fact*=i;}
    {
    cout<<"Factorial of"<<N<<"="<<fact;}
    }
return 0;


}
