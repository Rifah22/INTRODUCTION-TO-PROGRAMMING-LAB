#include<iostream>
using namespace std;

int main(){

cout<<"Hello World""\n""AIUB";

return 0;

}
