#include<iostream>
using namespace std;
int main (){

int n;
for (n=1;n<=100;n=n+1){

    cout<<n<<endl;
}


return 0;



}
