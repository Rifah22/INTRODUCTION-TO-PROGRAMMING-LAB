#include<iostream>
using namespace std;
int main(){
int i;
int count=0;

for (i=1;i<=50;i=i+1){
    if(i%2==0){

        cout<<i<<endl;
    }
    count=count+1;
}

return 0;


}
