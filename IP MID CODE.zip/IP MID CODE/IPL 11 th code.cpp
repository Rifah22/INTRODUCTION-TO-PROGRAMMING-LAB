#include<iostream>
#include<math.h>
using namespace std;
int main(){
float value1,value2;
char op;
cout<<"Type in your expression"<<endl;
cin>>value1>>op>>value2;
switch (op){
    case '+':
    cout<<"ADDITION:"<<value1+value2<<endl;
    break;
    case'-':
    cout<<"SUBTRACTION:"<<value1-value2<<endl;
    break;
    case'*':
    cout<<"MULTIPLICATION:"<<value1*value2<<endl;
    break;
    case'/':
    cout<<"DIVISION:"<<value1/value2<<endl;
    break;
    case'%':
    cout<<"MOD:"<<(int)value1%(int)value2<<endl;
    break;
    case'^':
    cout<<"POWER CALCULATION:"<<pow(value1,value2)<<endl;
    break;
    default:
        cout<<"INVALID OPERATOR"<<endl;}
return 0;
    }












