#include<iostream>
using namespace std;

int main(){

int a,b,sum;
a=5;
b=4;
sum=a+b;
cout<<sum;
return 0;



}
