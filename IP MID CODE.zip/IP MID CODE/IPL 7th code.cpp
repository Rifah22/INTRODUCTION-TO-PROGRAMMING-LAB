#include<iostream>
#include<math.h>
using namespace std;
int main (){

cout<<3*(2/4.0)+(3-1)<<endl;
cout<<(6+2)*((3-4)/2)<<endl;
cout<<20/(3+5)%2<<endl;
float a,b,c,d;
cin>>a;

cin>>b;

cin>>c;
float x1,x2;


x1=(-b+pow(pow(b,2)-4*a*c,1/2.0))/(2*a);
x2=(-b-pow(pow(b,2)-4*a*c,1/2.0))/(2*a);
cout<<"X1="<<x1<<endl;
cout<<"X2="<<x2<<endl;

return 0;





}

