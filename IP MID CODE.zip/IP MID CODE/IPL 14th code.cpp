#include<iostream>
using namespace std;
int main (){
int i;


for (int i=1;i<=50;i=i+1){

    if(i%2==1){

    cout<<i<<endl;
    }
}


return 0;



}
