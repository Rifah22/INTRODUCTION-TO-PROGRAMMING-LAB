#include<iostream>
using namespace std ;
int main(){

int i;
int count=0;
int N;
cin>>N;
//N=20
//1 5 9 13 17 21 25 29 33 37 41
for(i=1;count<N;i=i+4){//i=5
 if(i%3==0){
  cout<<i<<endl;

 }
 count=count+1;//count=1
}
return 0;





}
